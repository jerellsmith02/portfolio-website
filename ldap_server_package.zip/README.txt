LDAP Server Setup Package

Contains configuration files for setting up an OpenLDAP server on RHEL8 or via Docker.

Files included:
- add-suffix.ldif
- base.ldif
- user.ldif
- tls.ldif
- docker-compose.yml
