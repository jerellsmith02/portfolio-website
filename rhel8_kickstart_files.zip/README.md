# RHEL 8 Kickstart Example (Safe for Public Use)

This repository contains a GitHub-safe Kickstart configuration for automating
Red Hat Enterprise Linux 8 installations.

## Usage
1. Replace placeholders (`<HOSTNAME_HERE>`, `<ROOT_PASSWORD_HASH>`, etc.)
2. Generate password hashes using:
   ```
   openssl passwd -6
   ```
3. Point your installer to the Kickstart file:
   - PXE: `inst.ks=http://server/rhel8-kickstart.cfg`
   - USB/ISO: `ks=cdrom:/rhel8-kickstart.cfg`

## Security Notes
- Do NOT include real passwords or SSH private keys.
- Do NOT upload subscription credentials.

## Files
- `rhel8-kickstart.cfg`
- `README.md`
